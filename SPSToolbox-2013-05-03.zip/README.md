SPSToolbox
==========

Matlab toolbox for hypothesis testing using the method of Sign Perturbed Sums.
